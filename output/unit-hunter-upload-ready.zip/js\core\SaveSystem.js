// ============================================
// UNIT HUNTER — SaveSystem (localStorage meta)
// ============================================

const SAVE_KEY = 'unit_hunter_save';

export class SaveSystem {
  constructor() {
    this.data = this.load();
  }

  load() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (raw) return { ...this.getDefaults(), ...JSON.parse(raw) };
    } catch {}
    return this.getDefaults();
  }

  getDefaults() {
    return {
      bestLevel: 0,
      bestScore: 0,
      bestCombo: 0,
      totalCorrect: 0,
      totalRuns: 0,
      localLeaderboard: [],
      dailyChallenges: {},
      tutorialSeen: false,
      xp: 0,
      rank: 'D',
      achievements: {}
    };
  }

  save() {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(this.data));
    } catch (e) {
      console.warn('SaveSystem failed:', e);
    }
  }

  updateRunStats(run) {
    this.data.totalRuns++;
    this.data.totalCorrect += run.correctAnswers;
    if (run.level > this.data.bestLevel) this.data.bestLevel = run.level;
    if (run.score > this.data.bestScore) this.data.bestScore = run.score;
    if (run.maxCombo > this.data.bestCombo) this.data.bestCombo = run.maxCombo;
    this.save();
  }

  getStats() {
    return { ...this.data };
  }

  hasSeenTutorial() {
    return this.data.tutorialSeen === true;
  }

  markTutorialSeen() {
    this.data.tutorialSeen = true;
    this.save();
  }

  getDailyStatus(dateKey) {
    const entry = this.data.dailyChallenges?.[dateKey];
    return entry
      ? { ...entry }
      : { dateKey, rankedSubmitted: false, attempts: 0, bestScore: 0, bestLevel: 0 };
  }

  recordDailyAttempt(dateKey, result) {
    if (!dateKey) return false;
    if (!this.data.dailyChallenges || typeof this.data.dailyChallenges !== 'object') {
      this.data.dailyChallenges = {};
    }
    const current = this.getDailyStatus(dateKey);
    if (current.rankedSubmitted) return false;

    this.data.dailyChallenges[dateKey] = {
      ...current,
      rankedSubmitted: true,
      attempts: (current.attempts || 0) + 1,
      bestScore: Math.max(current.bestScore || 0, result.score || 0),
      bestLevel: Math.max(current.bestLevel || 0, result.level || 0),
      correctAnswers: result.correctAnswers || 0
    };
    this.save();
    return true;
  }

  // Local leaderboard
  addLocalEntry(name, score, level) {
    this.data.localLeaderboard.push({ name, score, level, date: Date.now() });
    this.data.localLeaderboard.sort((a, b) => b.score - a.score);
    this.data.localLeaderboard = this.data.localLeaderboard.slice(0, 50);
    this.save();
  }

  getLocalLeaderboard(topN = 10) {
    return this.data.localLeaderboard.slice(0, topN);
  }

  getProgression() {
    const xp = Number(this.data.xp || 0);
    const ranks = [['D',0],['C',500],['B',1500],['A',3500],['S',7000]];
    let index = 0;
    for (let i=0;i<ranks.length;i++) if (xp >= ranks[i][1]) index=i;
    const current=ranks[index], next=ranks[index+1];
    return { xp, rank: current[0], nextRank: next ? next[0] : 'MAX',
      progress: next ? Math.min(100, ((xp-current[1])/(next[1]-current[1]))*100) : 100 };
  }

  addProgression(run) {
    const earned=Math.max(25,Math.floor((run.correctAnswers||0)*12+(run.level||0)*8+(run.maxCombo||0)*5));
    this.data.xp=Number(this.data.xp||0)+earned;
    this.data.achievements=this.data.achievements||{};
    if((this.data.totalRuns||0)>=1)this.data.achievements.firstRun=true;
    if((run.maxCombo||0)>=10)this.data.achievements.combo10=true;
    if((run.maxCombo||0)>=25)this.data.achievements.combo25=true;
    if((run.level||0)>=10)this.data.achievements.level10=true;
    if(run.mode==='daily')this.data.achievements.bossHunter=true;
    const progress=this.getProgression();
    this.data.rank=progress.rank;
    this.save();
    return {earned,...progress};
  }}
