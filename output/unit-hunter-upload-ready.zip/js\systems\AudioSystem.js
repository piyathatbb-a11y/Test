  // ============================================
// UNIT HUNTER — AudioSystem (Web Audio API)
// ============================================

export class AudioSystem {
  constructor() {
    this.ctx = null;
    this.initialized = false;
    this.menuBgm = null;
    this.bgmTracks = { battle: [], boss: [], gameover: [] };
    this.activeBgm = null;
    this.activeBgmType = null;
    this.nextTrackIndex = { battle: 0, boss: 0, gameover: 0 };
    this.bgmToken = 0;
  }

  init() {
    if (this.initialized) return;
    try {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) return;
      this.ctx = new AudioContextClass();
      this.initialized = true;
    } catch (e) {
      console.warn('Web Audio API not available');
    }
  }

  resume() {
    if (this.ctx?.state === 'suspended') this.ctx.resume().catch(() => {});
  }

  playMenuBgm() {
    this.stopCombatBgm();
    if (!this.menuBgm) {
      this.menuBgm = new Audio('assets/audio/Neon Static.mp3');
      this.menuBgm.loop = true;
      this.menuBgm.volume = 0.28;
      this.menuBgm.preload = 'auto';
    }
    this.resume();
    this.menuBgm.play().catch(() => {});
  }

  stopMenuBgm() {
    if (!this.menuBgm) return;
    this.menuBgm.pause();
    this.menuBgm.currentTime = 0;
  }

  playCombatBgm(type = 'battle') {
    const tracks = {
      battle: ['assets/audio/battle2.mp3'],
      boss: ['assets/audio/boss battle1.mp3', 'assets/audio/boss battle2.mp3'],
      gameover: ['assets/audio/Gameover1.mp3', 'assets/audio/Gameover2.mp3']
    };
    if (!tracks[type]) type = 'battle';
    this.stopCombatBgm();
    const list = tracks[type];
    const index = this.nextTrackIndex[type] % list.length;
    this.nextTrackIndex[type] = (index + 1) % list.length;
    const audio = new Audio(list[index]);
    audio.volume = type === 'gameover' ? 0.32 : 0.28;
    audio.preload = 'auto';
    const token = ++this.bgmToken;
    audio.addEventListener('ended', () => {
      if (token !== this.bgmToken || this.activeBgm !== audio) return;
      this.playCombatBgm(type);
    }, { once: true });
    this.activeBgm = audio;
    this.activeBgmType = type;
    this.stopMenuBgm();
    this.resume();
    audio.play().catch(() => {});
  }

  stopCombatBgm() {
    this.bgmToken += 1;
    if (!this.activeBgm) return;
    this.activeBgm.pause();
    this.activeBgm.currentTime = 0;
    this.activeBgm = null;
    this.activeBgmType = null;
  }

  playBattleBgm() { this.playCombatBgm('battle'); }
  playBossBgm() { this.playCombatBgm('boss'); }
  playGameOverBgm() { this.playCombatBgm('gameover'); }

  playTone(freq, duration, type = 'sine', volume = 0.15) {
    if (!this.ctx) return;
    this.resume();
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
    gain.gain.setValueAtTime(volume, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + duration);
  }

  correct() {
    this.playTone(880, 0.15, 'sine', 0.1);
    setTimeout(() => this.playTone(1100, 0.2, 'sine', 0.1), 80);
  }

  wrong() {
    this.playTone(200, 0.4, 'sawtooth', 0.08);
    setTimeout(() => this.playTone(150, 0.3, 'sawtooth', 0.08), 100);
  }

  crit() {
    this.playTone(660, 0.1, 'square', 0.08);
    setTimeout(() => this.playTone(990, 0.1, 'square', 0.08), 50);
    setTimeout(() => this.playTone(1320, 0.3, 'square', 0.1), 100);
  }

  kill() {
    this.playTone(440, 0.1, 'sine', 0.1);
    setTimeout(() => this.playTone(554, 0.1, 'sine', 0.1), 100);
    setTimeout(() => this.playTone(659, 0.1, 'sine', 0.1), 200);
    setTimeout(() => this.playTone(880, 0.4, 'sine', 0.12), 300);
  }

  levelup() {
    this.playTone(523, 0.15, 'sine', 0.1);
    setTimeout(() => this.playTone(659, 0.15, 'sine', 0.1), 150);
    setTimeout(() => this.playTone(784, 0.15, 'sine', 0.1), 300);
    setTimeout(() => this.playTone(1047, 0.4, 'sine', 0.12), 450);
  }

  gameover() {
    this.playTone(440, 0.3, 'sawtooth', 0.08);
    setTimeout(() => this.playTone(330, 0.3, 'sawtooth', 0.08), 250);
    setTimeout(() => this.playTone(220, 0.6, 'sawtooth', 0.1), 500);
  }

  bossAttack() {
    this.playTone(100, 0.5, 'sawtooth', 0.1);
    setTimeout(() => this.playTone(80, 0.5, 'sawtooth', 0.12), 200);
  }

  tick() {
    this.playTone(2000, 0.05, 'sine', 0.03);
  }
}
